<?php
?>
<table class="wp-list-table widefat fixed posts">
<thead>
<tr>
	<th><?php _e('#Number','wlmg'); ?></th>
	<th><?php _e('License Code/License Number','wlmg'); ?></th>
	<th><?php _e('Actions','wlmg'); ?></th>
	<th><a href="<?php print admin_url('post.php?post='.$post->ID.'&task=delete_all'); ?>"><?php _e('Delete All','wlmg'); ?></a></th>
</tr>
</thead>
<tbody>
<?php if( count($licences) ): $i = 1; foreach($licences as $l): ?>
<tr>
	<td><?php print $i; ?></td>
	<td><?php print $l->licence_code; ?></td>
	<td><a href="<?php print admin_url('post.php?post='.$post->ID.'&task=delete_licence&id='.$l->licence_id); ?>"><?php _e('Delete','wlmg'); ?></a></td>
</tr>
<?php $i++; endforeach; else: ?>
<tr><td colspan="3"><?php _e('No licenses available for this product, please upload. (file must be in .txt format)','wlmg'); ?></td></tr>
<?php endif;?>
</tbody>
</table>
<p>
	<label><?php _e('Upload Licenses','wlmg'); ?></label>
	<input type="file" name="licences_file" value="" />
	<button type="submit" class="button-primary"><?php _e('Upload Now','wlmg'); ?></button>
</p>
<br />
<p>
<strong><?php _e('Alternatively,you can add license manually using the Input box below','wlmg'); ?></strong>
</p>
<p>
	<label><?php _e('Add License','wlmg'); ?></label>
	<input type="text" name="single_licence" value="" />
	<button type="submit" class="button-primary"><?php _e('Add License','wlmg'); ?></button>
</p>
<hr />
<p>
    <label><strong><?php _e('License Code Per Quantity' , 'wlmg'); ?></strong></label>
    <input type="text" name="license_unit" value="<?php if (get_post_meta($post->ID, 'license_unit', true) == ""){ echo '1' ;}else{ print get_post_meta($post->ID, 'license_unit', true); }?>" size="100" style="padding:3px;width:150px;" />
</p>
<p>
    <label><strong><?php _e('Use links as License Code' , 'wlmg'); ?></strong></label>
    <input type="checkbox" name="license_link" <?php if (get_post_meta($post->ID, 'license_link', true) == "1") { echo 'checked' ;} ?> />
</p>
<script>
jQuery('form#post').attr('enctype', 'multipart/form-data');
</script>
